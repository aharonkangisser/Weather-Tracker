﻿namespace wfProgPoeTask1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnRemoveCity = new System.Windows.Forms.Button();
            this.lblEnterCity = new System.Windows.Forms.Label();
            this.txtEnterCity = new System.Windows.Forms.TextBox();
            this.lblSelectCity = new System.Windows.Forms.Label();
            this.btnAddCity = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.lblMainHeading = new System.Windows.Forms.Label();
            this.lstbxCities = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMinTemp = new System.Windows.Forms.TextBox();
            this.lblMinTemp = new System.Windows.Forms.Label();
            this.txtMaxTemp = new System.Windows.Forms.TextBox();
            this.txtPercip = new System.Windows.Forms.TextBox();
            this.txtHumid = new System.Windows.Forms.TextBox();
            this.lblMaxTemp = new System.Windows.Forms.Label();
            this.txtWind = new System.Windows.Forms.TextBox();
            this.lblWind = new System.Windows.Forms.Label();
            this.lblPercip = new System.Windows.Forms.Label();
            this.lblHumid = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtWeatherPerDay = new System.Windows.Forms.TextBox();
            this.lblWeatherPerDay = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblHeading = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSelectedCity = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblWeatherMain = new System.Windows.Forms.Label();
            this.lblPercipHum = new System.Windows.Forms.Label();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(820, 437);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblWeatherPerDay);
            this.tabPage1.Controls.Add(this.txtWeatherPerDay);
            this.tabPage1.Controls.Add(this.btnClear);
            this.tabPage1.Controls.Add(this.btnSave);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.lblHumid);
            this.tabPage1.Controls.Add(this.lblPercip);
            this.tabPage1.Controls.Add(this.lblWind);
            this.tabPage1.Controls.Add(this.txtWind);
            this.tabPage1.Controls.Add(this.lblMaxTemp);
            this.tabPage1.Controls.Add(this.txtHumid);
            this.tabPage1.Controls.Add(this.txtPercip);
            this.tabPage1.Controls.Add(this.txtMaxTemp);
            this.tabPage1.Controls.Add(this.lblMinTemp);
            this.tabPage1.Controls.Add(this.txtMinTemp);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.btnRemoveCity);
            this.tabPage1.Controls.Add(this.lblEnterCity);
            this.tabPage1.Controls.Add(this.txtEnterCity);
            this.tabPage1.Controls.Add(this.lblSelectCity);
            this.tabPage1.Controls.Add(this.btnAddCity);
            this.tabPage1.Controls.Add(this.pnlMain);
            this.tabPage1.Controls.Add(this.lstbxCities);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(812, 411);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Home";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnRemoveCity
            // 
            this.btnRemoveCity.Location = new System.Drawing.Point(136, 180);
            this.btnRemoveCity.Name = "btnRemoveCity";
            this.btnRemoveCity.Size = new System.Drawing.Size(124, 23);
            this.btnRemoveCity.TabIndex = 7;
            this.btnRemoveCity.Text = "Remove city";
            this.btnRemoveCity.UseVisualStyleBackColor = true;
            this.btnRemoveCity.Click += new System.EventHandler(this.btnRemoveCity_Click);
            // 
            // lblEnterCity
            // 
            this.lblEnterCity.AutoSize = true;
            this.lblEnterCity.Location = new System.Drawing.Point(133, 136);
            this.lblEnterCity.Name = "lblEnterCity";
            this.lblEnterCity.Size = new System.Drawing.Size(127, 13);
            this.lblEnterCity.TabIndex = 6;
            this.lblEnterCity.Text = "Please enter a city to add";
            // 
            // txtEnterCity
            // 
            this.txtEnterCity.Location = new System.Drawing.Point(134, 152);
            this.txtEnterCity.Name = "txtEnterCity";
            this.txtEnterCity.Size = new System.Drawing.Size(126, 20);
            this.txtEnterCity.TabIndex = 5;
            // 
            // lblSelectCity
            // 
            this.lblSelectCity.AutoSize = true;
            this.lblSelectCity.Location = new System.Drawing.Point(7, 90);
            this.lblSelectCity.Name = "lblSelectCity";
            this.lblSelectCity.Size = new System.Drawing.Size(98, 13);
            this.lblSelectCity.TabIndex = 4;
            this.lblSelectCity.Text = "Please select a city";
            // 
            // btnAddCity
            // 
            this.btnAddCity.Location = new System.Drawing.Point(134, 110);
            this.btnAddCity.Name = "btnAddCity";
            this.btnAddCity.Size = new System.Drawing.Size(126, 23);
            this.btnAddCity.TabIndex = 3;
            this.btnAddCity.Text = "Add city";
            this.btnAddCity.UseVisualStyleBackColor = true;
            this.btnAddCity.Click += new System.EventHandler(this.btnAddCity_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlMain.Controls.Add(this.lblMainHeading);
            this.pnlMain.Location = new System.Drawing.Point(7, 6);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(799, 70);
            this.pnlMain.TabIndex = 2;
            // 
            // lblMainHeading
            // 
            this.lblMainHeading.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainHeading.Location = new System.Drawing.Point(270, 11);
            this.lblMainHeading.Name = "lblMainHeading";
            this.lblMainHeading.Size = new System.Drawing.Size(222, 49);
            this.lblMainHeading.TabIndex = 1;
            this.lblMainHeading.Text = "Edit Forecast";
            this.lblMainHeading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lstbxCities
            // 
            this.lstbxCities.FormattingEnabled = true;
            this.lstbxCities.Location = new System.Drawing.Point(7, 109);
            this.lstbxCities.Name = "lstbxCities";
            this.lstbxCities.Size = new System.Drawing.Size(120, 95);
            this.lstbxCities.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(812, 411);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "View all";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(844, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(277, 205);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 8;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(277, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Please pick the date ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtMinTemp
            // 
            this.txtMinTemp.Location = new System.Drawing.Point(7, 261);
            this.txtMinTemp.Name = "txtMinTemp";
            this.txtMinTemp.Size = new System.Drawing.Size(189, 20);
            this.txtMinTemp.TabIndex = 12;
            // 
            // lblMinTemp
            // 
            this.lblMinTemp.AutoSize = true;
            this.lblMinTemp.Location = new System.Drawing.Point(10, 242);
            this.lblMinTemp.Name = "lblMinTemp";
            this.lblMinTemp.Size = new System.Drawing.Size(186, 13);
            this.lblMinTemp.TabIndex = 13;
            this.lblMinTemp.Text = "Please enter the minimum temperature";
            // 
            // txtMaxTemp
            // 
            this.txtMaxTemp.Location = new System.Drawing.Point(562, 261);
            this.txtMaxTemp.Name = "txtMaxTemp";
            this.txtMaxTemp.Size = new System.Drawing.Size(200, 20);
            this.txtMaxTemp.TabIndex = 14;
            // 
            // txtPercip
            // 
            this.txtPercip.Location = new System.Drawing.Point(7, 315);
            this.txtPercip.Name = "txtPercip";
            this.txtPercip.Size = new System.Drawing.Size(189, 20);
            this.txtPercip.TabIndex = 15;
            // 
            // txtHumid
            // 
            this.txtHumid.Location = new System.Drawing.Point(562, 315);
            this.txtHumid.Name = "txtHumid";
            this.txtHumid.Size = new System.Drawing.Size(200, 20);
            this.txtHumid.TabIndex = 16;
            // 
            // lblMaxTemp
            // 
            this.lblMaxTemp.AutoSize = true;
            this.lblMaxTemp.Location = new System.Drawing.Point(562, 241);
            this.lblMaxTemp.Name = "lblMaxTemp";
            this.lblMaxTemp.Size = new System.Drawing.Size(189, 13);
            this.lblMaxTemp.TabIndex = 18;
            this.lblMaxTemp.Text = "Please enter the maximum temperature";
            // 
            // txtWind
            // 
            this.txtWind.Location = new System.Drawing.Point(277, 315);
            this.txtWind.Name = "txtWind";
            this.txtWind.Size = new System.Drawing.Size(200, 20);
            this.txtWind.TabIndex = 19;
            // 
            // lblWind
            // 
            this.lblWind.AutoSize = true;
            this.lblWind.Location = new System.Drawing.Point(280, 296);
            this.lblWind.Name = "lblWind";
            this.lblWind.Size = new System.Drawing.Size(138, 13);
            this.lblWind.TabIndex = 20;
            this.lblWind.Text = "Please enter the windspeed";
            // 
            // lblPercip
            // 
            this.lblPercip.AutoSize = true;
            this.lblPercip.Location = new System.Drawing.Point(13, 296);
            this.lblPercip.Name = "lblPercip";
            this.lblPercip.Size = new System.Drawing.Size(144, 13);
            this.lblPercip.TabIndex = 21;
            this.lblPercip.Text = "Please enter the percipitation";
            // 
            // lblHumid
            // 
            this.lblHumid.AutoSize = true;
            this.lblHumid.Location = new System.Drawing.Point(565, 296);
            this.lblHumid.Name = "lblHumid";
            this.lblHumid.Size = new System.Drawing.Size(125, 13);
            this.lblHumid.TabIndex = 22;
            this.lblHumid.Text = "Please enter the humidity";
            this.lblHumid.Click += new System.EventHandler(this.label8_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(499, 90);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(263, 114);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(677, 370);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(85, 23);
            this.btnSave.TabIndex = 24;
            this.btnSave.Text = "Save ";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(562, 371);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(92, 23);
            this.btnClear.TabIndex = 25;
            this.btnClear.Text = "Clear ";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtWeatherPerDay
            // 
            this.txtWeatherPerDay.Location = new System.Drawing.Point(277, 261);
            this.txtWeatherPerDay.Name = "txtWeatherPerDay";
            this.txtWeatherPerDay.Size = new System.Drawing.Size(200, 20);
            this.txtWeatherPerDay.TabIndex = 27;
            // 
            // lblWeatherPerDay
            // 
            this.lblWeatherPerDay.AutoSize = true;
            this.lblWeatherPerDay.Location = new System.Drawing.Point(280, 242);
            this.lblWeatherPerDay.Name = "lblWeatherPerDay";
            this.lblWeatherPerDay.Size = new System.Drawing.Size(178, 13);
            this.lblWeatherPerDay.TabIndex = 28;
            this.lblWeatherPerDay.Text = "Please enter the weather for the day";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Transparent;
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(812, 411);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "View Individual";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.lblHeading);
            this.panel1.Location = new System.Drawing.Point(4, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(799, 70);
            this.panel1.TabIndex = 0;
            // 
            // lblHeading
            // 
            this.lblHeading.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(178, 15);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(434, 43);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Quick display of specific city";
            this.lblHeading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(7, 7);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(799, 70);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(159, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(436, 49);
            this.label3.TabIndex = 0;
            this.label3.Text = "Forecast display of all cities";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnDisplay);
            this.groupBox1.Controls.Add(this.lblPercipHum);
            this.groupBox1.Controls.Add(this.lblWeatherMain);
            this.groupBox1.Controls.Add(this.lblDate);
            this.groupBox1.Controls.Add(this.lblSelectedCity);
            this.groupBox1.Location = new System.Drawing.Point(107, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(587, 280);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // lblSelectedCity
            // 
            this.lblSelectedCity.AutoSize = true;
            this.lblSelectedCity.Location = new System.Drawing.Point(31, 58);
            this.lblSelectedCity.Name = "lblSelectedCity";
            this.lblSelectedCity.Size = new System.Drawing.Size(0, 13);
            this.lblSelectedCity.TabIndex = 0;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(31, 94);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(0, 13);
            this.lblDate.TabIndex = 1;
            // 
            // lblWeatherMain
            // 
            this.lblWeatherMain.AutoSize = true;
            this.lblWeatherMain.Location = new System.Drawing.Point(31, 136);
            this.lblWeatherMain.Name = "lblWeatherMain";
            this.lblWeatherMain.Size = new System.Drawing.Size(0, 13);
            this.lblWeatherMain.TabIndex = 2;
            // 
            // lblPercipHum
            // 
            this.lblPercipHum.AutoSize = true;
            this.lblPercipHum.Location = new System.Drawing.Point(31, 186);
            this.lblPercipHum.Name = "lblPercipHum";
            this.lblPercipHum.Size = new System.Drawing.Size(0, 13);
            this.lblPercipHum.TabIndex = 3;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(34, 238);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(528, 23);
            this.btnDisplay.TabIndex = 4;
            this.btnDisplay.Text = "Display Info";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 476);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnRemoveCity;
        private System.Windows.Forms.Label lblEnterCity;
        private System.Windows.Forms.TextBox txtEnterCity;
        private System.Windows.Forms.Label lblSelectCity;
        private System.Windows.Forms.Button btnAddCity;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblMainHeading;
        private System.Windows.Forms.ListBox lstbxCities;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label lblHumid;
        private System.Windows.Forms.Label lblPercip;
        private System.Windows.Forms.Label lblWind;
        private System.Windows.Forms.TextBox txtWind;
        private System.Windows.Forms.Label lblMaxTemp;
        private System.Windows.Forms.TextBox txtHumid;
        private System.Windows.Forms.TextBox txtPercip;
        private System.Windows.Forms.TextBox txtMaxTemp;
        private System.Windows.Forms.Label lblMinTemp;
        private System.Windows.Forms.TextBox txtMinTemp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtWeatherPerDay;
        private System.Windows.Forms.Label lblWeatherPerDay;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Label lblPercipHum;
        private System.Windows.Forms.Label lblWeatherMain;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblSelectedCity;
    }
}

