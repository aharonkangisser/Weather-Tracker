﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfProgPoeTask1
{
    public partial class Form1 : Form
    {

        List<string> lstCity = new List<string>();
        

        public Form1()
        {
            InitializeComponent();
            DisplayLabels();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnAddCity_Click(object sender, EventArgs e)
        {
            if (txtEnterCity.Text == string.Empty)
            {

                MessageBox.Show("Please enter a City", "Error");
            }
            else
            {

                lstCity.Add(txtEnterCity.Text);

                lstbxCities.Items.Add(txtEnterCity.Text);
                txtEnterCity.Clear();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lstbxCities.Items.Add("Cape Town");
            lstbxCities.Items.Add("Johannesburg");
            lstbxCities.Items.Add("Durban");


            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

        }

        private void btnRemoveCity_Click(object sender, EventArgs e)
        {
            lstbxCities.Items.Remove(lstbxCities.SelectedItem);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        public void DisplayLabels() {
            // lstCity = lstbxCities;
           // lstbxCities.DataSource = lstCity;

            foreach (string s in lstCity) {

                
                    }
            


        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            
                lblSelectedCity.Text = "The City: " + lstbxCities.SelectedItem.ToString();
            
            lblDate.Text = "The Date " + dateTimePicker1.Value; 
            //lblPercipHum.Text = " the Pericipitation will be "+ txtPercip.Text + " " +" and the humidity will be " + txtHumid.Text;
            //lblWeatherMain.Text = "The Weather will be " + txtWeatherPerDay.Text + " " + txtMaxTemp.Text + " " + txtMinTemp.Text;

            if (txtHumid.Text == string.Empty && txtPercip.Text == string.Empty && txtWind.Text== string.Empty)
            {
                MessageBox.Show(lblHumid.Text +lblPercip.Text + " field", "Error");
               // this.lblHumid.ForeColor = Color.Red;
            }
            else
            {
                lblPercipHum.Text = " the Pericipitation will be " + txtPercip.Text + " " + " and the humidity will be " + txtHumid.Text + " with windspeed of" + txtWind.Text + "km/h";

            }
            if (txtMaxTemp.Text == string.Empty && txtMinTemp.Text == string.Empty && txtWeatherPerDay.Text == string.Empty)
            {

                MessageBox.Show(lblMaxTemp.Text + lblMinTemp.Text + lblWeatherPerDay + " field", "Error");
            }
            else {

                lblWeatherMain.Text = "The Weather will be " + txtWeatherPerDay.Text + " with a high of " + txtMaxTemp.Text + " and a low of " + txtMinTemp.Text;
            }

                      

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtHumid.Text == string.Empty)
            {
                MessageBox.Show(lblHumid.Text + " field", "Error");
                this.lblHumid.ForeColor = Color.Red;
            }
            else {
                this.lblHumid.ForeColor = Color.Black;
            }
            if (txtMaxTemp.Text == string.Empty)
            {
                MessageBox.Show(lblMaxTemp.Text + " field", "Error");
                this.lblMaxTemp.ForeColor = Color.Red;
            }
            else
            {
                this.lblMaxTemp.ForeColor = Color.Black;
            }
            if (txtMinTemp.Text == string.Empty)
            {
                MessageBox.Show(lblMinTemp.Text + " field", "Error");
                this.lblMinTemp.ForeColor = Color.Red;
            }
            else
            {
                this.lblMinTemp.ForeColor = Color.Black;
            }
            if (txtPercip.Text == string.Empty)
            {
                MessageBox.Show(lblPercip.Text + " field", "Error");
                this.lblPercip.ForeColor = Color.Red;
            }
            else
            {
                this.lblPercip.ForeColor = Color.Black;
            }
            if (txtWind.Text == string.Empty)
            {
                MessageBox.Show(lblWind.Text + " field", "Error");
                this.lblWind.ForeColor = Color.Red;
            }
            else
            {
                this.lblWind.ForeColor = Color.Black;
            }
            if (txtWeatherPerDay.Text == string.Empty)
            {
                MessageBox.Show(lblWeatherPerDay.Text + " field", "Error");
                this.lblWeatherPerDay.ForeColor = Color.Red;
            }
            else
            {
                this.lblWeatherPerDay.ForeColor = Color.Black;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtHumid.Clear();
            txtMaxTemp.Clear();
            txtMinTemp.Clear();
            txtPercip.Clear();
            txtWeatherPerDay.Clear();
            txtWind.Clear();
            
        }
    }
}
